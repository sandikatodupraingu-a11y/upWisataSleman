import React from "react";

function Footer() {
  return (
    <footer className="footer">
      <p>
        <strong>TECHNOVACATION FTTI 2024</strong>, organized by <strong>Universitas Jenderal Achmad Yani Yogyakarta</strong>. Website developed by <strong>Kelompok 4</strong> with team members: <strong>Dwi</strong>, <strong>Andika</strong>, <strong>Putri</strong>, <strong>Erika</strong>, <strong>El</strong>.
      </p>
      <p>
        Logos and data are sourced from the <strong>Dinas Pariwisata Kab Sleman</strong> and <strong>Kemenparekraf</strong>.
      </p>
      <p className="footer-copyright">
        <span>Website © 2024</span>
        <span className="footer-logo"><img src="assets/img/logo-2.png" alt="UpDesaWisata Logo" /></span>
      </p>
    </footer>
  );
}

export default Footer;
